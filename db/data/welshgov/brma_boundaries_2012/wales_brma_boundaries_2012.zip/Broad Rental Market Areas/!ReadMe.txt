This zip file contains a copy of the Broad Rental Market Areas boundary dataset released by Rent Officers Wales (part of the Housing Division of the Welsh Government) on 23 September 2014. This dataset covers Wales only.

The dataset was released in Esri Shapefile format. I have also created and enclosed a copy in MapInfo TAB format.

The dataset is reusable under the Open Government Licence.

Please see the Doc folder for more details.

-- Owen Boswarva, 24/09/2014